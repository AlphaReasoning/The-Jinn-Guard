# Enterprise17.2 Validation Report

## PASS

- Enforcement kernel validation
- Safe-mode kernel validation
- Fresh install validation
- RuntimeDirectory validation
- Safe-mode systemd validation
- Release binary validation
- Socket validation
- Verdict-map saturation remediation
- Verdict-map soak test
- Installer verification fixed with fixed-string binary marker checks
- Fresh ZIP packaging includes `policy.yaml` for self-contained install

## Evidence

Safe-mode banner:

```text
[safe-mode] LSM audit-only mode active; deny decisions disabled
```

Runtime:

```text
active
```

Runtime directory:

```text
RUNTIME_DIR_OK
```

Socket:

```text
SOCKET_OK
```

External command validation:

```text
ENV_OK
ECHO_OK
CLEAR_OK
```

Verdict-map soak:

```text
NO_VERDICT_MAP_FAILURES
```

Installer marker verification:

```text
grep -aFq "JINNGUARD_SAFE_MODE" "$BINARY"
grep -aFq "[safe-mode] LSM audit-only mode active; deny decisions disabled" "$BINARY"
```
